/*************************************************************************
 *
 * Copyright (C) 2018-2025 Ruilin Peng (Nick) <pymumu@gmail.com>.
 *
 * smartdns is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * smartdns is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "client.h"
#include "smartdns/dns.h"
#include "include/utils.h"
#include "server.h"
#include "gtest/gtest.h"
#include <fcntl.h>
#include <fstream>
#include <sys/stat.h>
#include <sys/types.h>

/* clang-format off */
#include "smartdns/dns_cache.h"
/* clang-format on */

class Cache : public ::testing::Test
{
  protected:
	void SetUp() override {}

	void TearDown() override {}
};

TEST_F(Cache, min)
{
	smartdns::MockServer server_upstream;
	smartdns::Server server;

	server_upstream.Start("udp://0.0.0.0:61053", [](struct smartdns::ServerRequestContext *request) {
		std::string domain = request->domain;
		if (request->domain.length() == 0) {
			return smartdns::SERVER_REQUEST_ERROR;
		}

		if (request->qtype == DNS_T_A) {
			unsigned char addr[4] = {1, 2, 3, 4};
			dns_add_A(request->response_packet, DNS_RRS_AN, domain.c_str(), 0, addr);
		} else if (request->qtype == DNS_T_AAAA) {
			unsigned char addr[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
			dns_add_AAAA(request->response_packet, DNS_RRS_AN, domain.c_str(), 0, addr);
		} else {
			return smartdns::SERVER_REQUEST_ERROR;
		}

		request->response_packet->head.rcode = DNS_RC_NOERROR;
		return smartdns::SERVER_REQUEST_OK;
	});

	server.Start(R"""(bind [::]:60053
server 127.0.0.1:61053
cache-size 1
rr-ttl-min 1
speed-check-mode none
response-mode fastest-response
)""");
	smartdns::Client client;
	ASSERT_TRUE(client.Query("a.com", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_EQ(client.GetAnswer()[0].GetTTL(), 1);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
}

TEST_F(Cache, update_timer_after_destroy)
{
	struct dns_cache_key cache_key;

	ASSERT_EQ(dns_cache_init(16, 0, NULL), 0);
	dns_cache_destroy();

	cache_key.domain = "shutdown.example";
	cache_key.qtype = DNS_T_A;
	cache_key.dns_group_name = "";
	cache_key.query_flag = 0;

	EXPECT_EQ(dns_cache_update_timer(&cache_key, 300), -1);
}

TEST_F(Cache, max_reply_ttl)
{
	smartdns::MockServer server_upstream;
	smartdns::Server server;

	server_upstream.Start("udp://0.0.0.0:61053", [](struct smartdns::ServerRequestContext *request) {
		std::string domain = request->domain;
		if (request->domain.length() == 0) {
			return smartdns::SERVER_REQUEST_ERROR;
		}

		if (request->qtype == DNS_T_A) {
			unsigned char addr[4] = {1, 2, 3, 4};
			dns_add_A(request->response_packet, DNS_RRS_AN, domain.c_str(), 0, addr);
		} else if (request->qtype == DNS_T_AAAA) {
			unsigned char addr[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
			dns_add_AAAA(request->response_packet, DNS_RRS_AN, domain.c_str(), 0, addr);
		} else {
			return smartdns::SERVER_REQUEST_ERROR;
		}

		request->response_packet->head.rcode = DNS_RC_NOERROR;
		return smartdns::SERVER_REQUEST_OK;
	});

	server.Start(R"""(bind [::]:60053
server 127.0.0.1:61053
cache-size 1
rr-ttl-min 600
rr-ttl-reply-max 5
speed-check-mode none
response-mode fastest-response
)""");
	smartdns::Client client;
	ASSERT_TRUE(client.Query("a.com", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_EQ(client.GetAnswer()[0].GetTTL(), 5);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");

	sleep(1);

	ASSERT_TRUE(client.Query("a.com", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_EQ(client.GetAnswer()[0].GetTTL(), 5);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
}

TEST_F(Cache, max_reply_ttl_expired)
{
	smartdns::MockServer server_upstream;
	smartdns::Server server;

	server_upstream.Start("udp://0.0.0.0:61053", [](struct smartdns::ServerRequestContext *request) {
		std::string domain = request->domain;
		if (request->domain.length() == 0) {
			return smartdns::SERVER_REQUEST_ERROR;
		}

		if (request->qtype == DNS_T_A) {
			unsigned char addr[4] = {1, 2, 3, 4};
			dns_add_A(request->response_packet, DNS_RRS_AN, domain.c_str(), 0, addr);
		} else if (request->qtype == DNS_T_AAAA) {
			unsigned char addr[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
			dns_add_AAAA(request->response_packet, DNS_RRS_AN, domain.c_str(), 0, addr);
		} else {
			return smartdns::SERVER_REQUEST_ERROR;
		}

		request->response_packet->head.rcode = DNS_RC_NOERROR;
		return smartdns::SERVER_REQUEST_OK;
	});

	server.Start(R"""(bind [::]:60053
server 127.0.0.1:61053
cache-size 1
rr-ttl-min 600
rr-ttl-reply-max 6
)""");
	smartdns::Client client;
	ASSERT_TRUE(client.Query("a.com", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_EQ(client.GetAnswer()[0].GetTTL(), 3);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");

	ASSERT_TRUE(client.Query("a.com", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_GE(client.GetAnswer()[0].GetTTL(), 5);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
}

TEST_F(Cache, prefetch)
{
	smartdns::MockServer server_upstream;
	smartdns::MockServer server_upstream1;
	smartdns::MockServer server_upstream2;
	smartdns::Server server;

	server_upstream.Start("udp://0.0.0.0:61053", [](struct smartdns::ServerRequestContext *request) {
		if (request->qtype != DNS_T_A) {
			return smartdns::SERVER_REQUEST_SOA;
		}

		smartdns::MockServer::AddIP(request, request->domain.c_str(), "9.10.11.12", 611);
		return smartdns::SERVER_REQUEST_OK;
	});

	server_upstream1.Start("udp://0.0.0.0:62053", [](struct smartdns::ServerRequestContext *request) {
		if (request->qtype != DNS_T_A) {
			return smartdns::SERVER_REQUEST_SOA;
		}

		smartdns::MockServer::AddIP(request, request->domain.c_str(), "1.2.3.4", 611);
		return smartdns::SERVER_REQUEST_OK;
	});

	server_upstream2.Start("udp://0.0.0.0:63053", [](struct smartdns::ServerRequestContext *request) {
		if (request->qtype != DNS_T_A) {
			return smartdns::SERVER_REQUEST_SOA;
		}

		smartdns::MockServer::AddIP(request, request->domain.c_str(), "5.6.7.8", 611);
		return smartdns::SERVER_REQUEST_OK;
	});

	server.MockPing(PING_TYPE_ICMP, "1.2.3.4", 60, 100);
	server.MockPing(PING_TYPE_ICMP, "5.6.7.8", 60, 110);
	server.MockPing(PING_TYPE_ICMP, "9.10.11.12", 60, 110);

	server.Start(R"""(bind [::]:60053
bind [::]:60153 -group g1
server 127.0.0.1:61053
server 127.0.0.1:62053 -group g1 -exclude-default-group
server 127.0.0.1:63053 -group g2
prefetch-domain yes
rr-ttl-max 2
serve-expired no
)""");
	smartdns::Client client;
	ASSERT_TRUE(client.Query("a.com", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");

	ASSERT_TRUE(client.Query("a.com", 60153));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");

	sleep(1);

	ASSERT_TRUE(client.Query("a.com", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 2);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");

	sleep(1);

	ASSERT_TRUE(client.Query("a.com", 60153));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
}

TEST_F(Cache, nocache)
{
	smartdns::MockServer server_upstream;
	smartdns::Server server;

	server_upstream.Start("udp://0.0.0.0:61053", [](struct smartdns::ServerRequestContext *request) {
		std::string domain = request->domain;
		if (request->domain.length() == 0) {
			return smartdns::SERVER_REQUEST_ERROR;
		}

		usleep(15000);

		if (request->qtype == DNS_T_A) {
			unsigned char addr[4] = {1, 2, 3, 4};
			dns_add_A(request->response_packet, DNS_RRS_AN, domain.c_str(), 0, addr);
		} else if (request->qtype == DNS_T_AAAA) {
			unsigned char addr[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
			dns_add_AAAA(request->response_packet, DNS_RRS_AN, domain.c_str(), 0, addr);
		} else {
			return smartdns::SERVER_REQUEST_ERROR;
		}

		request->response_packet->head.rcode = DNS_RC_NOERROR;
		return smartdns::SERVER_REQUEST_OK;
	});

	server.Start(R"""(bind [::]:60053
server 127.0.0.1:61053
cache-size 100
rr-ttl-min 600
rr-ttl-reply-max 5
domain-rules /a.com/ --no-cache
)""");
	smartdns::Client client;
	ASSERT_TRUE(client.Query("a.com", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_EQ(client.GetAnswer()[0].GetTTL(), 5);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");

	ASSERT_TRUE(client.Query("a.com", 60053));
	EXPECT_GT(client.GetQueryTime(), 10);
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_EQ(client.GetAnswer()[0].GetTTL(), 5);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
}

TEST_F(Cache, save_file)
{
	smartdns::MockServer server_upstream;
	auto cache_file = "/tmp/smartdns_cache." + smartdns::GenerateRandomString(10);
	std::string conf = R"""(
bind [::]:60053@lo
server 127.0.0.1:62053
cache-persist yes
dualstack-ip-selection no
)""";

	conf += "cache-file " + cache_file;
	Defer
	{
		unlink(cache_file.c_str());
	};

	server_upstream.Start("udp://0.0.0.0:62053", [](struct smartdns::ServerRequestContext *request) {
		if (request->qtype == DNS_T_A) {
			smartdns::MockServer::AddIP(request, request->domain.c_str(), "1.2.3.4");
			return smartdns::SERVER_REQUEST_OK;
		}
		return smartdns::SERVER_REQUEST_SOA;
	});
	{
		smartdns::Server server;
		server.Start(conf);
		smartdns::Client client;

		ASSERT_TRUE(client.Query("a.com", 60053));
		std::cout << client.GetResult() << std::endl;
		ASSERT_EQ(client.GetAnswerNum(), 1);
		EXPECT_EQ(client.GetStatus(), "NOERROR");
		EXPECT_LT(client.GetQueryTime(), 100);
		EXPECT_EQ(client.GetAnswer()[0].GetTTL(), 3);
		EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
		server.Stop();
		usleep(200 * 1000);
	}

	ASSERT_EQ(access(cache_file.c_str(), F_OK), 0);

	std::fstream fs(cache_file, std::ios::in);
	struct dns_cache_file head;
	memset(&head, 0, sizeof(head));
	fs.read((char *)&head, sizeof(head));
	EXPECT_EQ(head.magic, MAGIC_NUMBER);
	EXPECT_EQ(head.cache_number, 1);
}

TEST_F(Cache, corrupt_file)
{
	smartdns::MockServer server_upstream;
	auto cache_file = "/tmp/smartdns_cache." + smartdns::GenerateRandomString(10);
	std::string conf = R"""(
bind [::]:60053@lo
server 127.0.0.1:62053
dualstack-ip-selection no
cache-persist yes
)""";

	conf += "cache-file " + cache_file;
	Defer
	{
		unlink(cache_file.c_str());
	};

	server_upstream.Start("udp://0.0.0.0:62053", [](struct smartdns::ServerRequestContext *request) {
		if (request->qtype == DNS_T_A) {
			smartdns::MockServer::AddIP(request, request->domain.c_str(), "1.2.3.4");
			return smartdns::SERVER_REQUEST_OK;
		}
		return smartdns::SERVER_REQUEST_SOA;
	});
	{
		smartdns::Server server;
		server.Start(conf);
		smartdns::Client client;

		ASSERT_TRUE(client.Query("a.com", 60053));
		std::cout << client.GetResult() << std::endl;
		ASSERT_EQ(client.GetAnswerNum(), 1);
		EXPECT_EQ(client.GetStatus(), "NOERROR");
		EXPECT_LT(client.GetQueryTime(), 100);
		EXPECT_EQ(client.GetAnswer()[0].GetTTL(), 3);
		EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
		server.Stop();
		usleep(200 * 1000);
	}

	ASSERT_EQ(access(cache_file.c_str(), F_OK), 0);

	int fd = open(cache_file.c_str(), O_RDWR);
	ASSERT_NE(fd, -1);
	srandom(time(NULL));
	off_t file_size = lseek(fd, 0, SEEK_END);
	off_t offset = random() % (file_size - 300);
	std::cout << "try make corrupt at " << offset << ", file size: " << file_size << std::endl;
	lseek(fd, offset, SEEK_SET);
	for (int i = 0; i < 300; i++) {
		unsigned char c = random() % 256;
		write(fd, &c, 1);
	}
	close(fd);
	{
		smartdns::Server server;
		server.Start(conf);
		smartdns::Client client;

		ASSERT_TRUE(client.Query("a.com", 60053));
		std::cout << client.GetResult() << std::endl;
		ASSERT_EQ(client.GetAnswerNum(), 1);
		EXPECT_EQ(client.GetStatus(), "NOERROR");
		EXPECT_LT(client.GetQueryTime(), 100);
		EXPECT_EQ(client.GetAnswer()[0].GetTTL(), 3);
		EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
		server.Stop();
		usleep(200 * 1000);
	}
}

TEST_F(Cache, invalid_data_size_file)
{
	smartdns::MockServer server_upstream;
	auto cache_file = "/tmp/smartdns_cache." + smartdns::GenerateRandomString(10);
	std::string conf = R"""(
bind [::]:60053@lo
server 127.0.0.1:62053
dualstack-ip-selection no
cache-persist yes
)""";

	conf += "cache-file " + cache_file;
	Defer
	{
		unlink(cache_file.c_str());
	};

	struct dns_cache_file file_head;
	memset(&file_head, 0, sizeof(file_head));
	file_head.magic = MAGIC_NUMBER;
	snprintf(file_head.version, sizeof(file_head.version), "%s", dns_cache_file_version());
	file_head.cache_number = 1;

	struct dns_cache_record record;
	memset(&record, 0, sizeof(record));
	record.magic = MAGIC_RECORD;

	struct dns_cache_data_head data_head;
	memset(&data_head, 0, sizeof(data_head));
	data_head.magic = MAGIC_CACHE_DATA;
	data_head.size = -1;

	int fd = open(cache_file.c_str(), O_CREAT | O_TRUNC | O_WRONLY, 0640);
	ASSERT_NE(fd, -1);
	ASSERT_EQ(write(fd, &file_head, sizeof(file_head)), (ssize_t)sizeof(file_head));
	ASSERT_EQ(write(fd, &record, sizeof(record)), (ssize_t)sizeof(record));
	ASSERT_EQ(write(fd, &data_head, sizeof(data_head)), (ssize_t)sizeof(data_head));
	close(fd);

	server_upstream.Start("udp://0.0.0.0:62053", [](struct smartdns::ServerRequestContext *request) {
		if (request->qtype == DNS_T_A) {
			smartdns::MockServer::AddIP(request, request->domain.c_str(), "1.2.3.4");
			return smartdns::SERVER_REQUEST_OK;
		}
		return smartdns::SERVER_REQUEST_SOA;
	});

	smartdns::Server server;
	server.Start(conf);
	smartdns::Client client;

	ASSERT_TRUE(client.Query("a.com", 60053));
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
}

TEST_F(Cache, truncated_data_file)
{
	smartdns::MockServer server_upstream;
	auto cache_file = "/tmp/smartdns_cache." + smartdns::GenerateRandomString(10);
	std::string conf = R"""(
bind [::]:60053@lo
server 127.0.0.1:62053
dualstack-ip-selection no
cache-persist yes
)""";

	conf += "cache-file " + cache_file;
	Defer
	{
		unlink(cache_file.c_str());
	};

	struct dns_cache_file file_head;
	memset(&file_head, 0, sizeof(file_head));
	file_head.magic = MAGIC_NUMBER;
	snprintf(file_head.version, sizeof(file_head.version), "%s", dns_cache_file_version());
	file_head.cache_number = 1;

	struct dns_cache_record record;
	memset(&record, 0, sizeof(record));
	record.magic = MAGIC_RECORD;

	struct dns_cache_data_head data_head;
	memset(&data_head, 0, sizeof(data_head));
	data_head.magic = MAGIC_CACHE_DATA;
	data_head.size = 4;

	int fd = open(cache_file.c_str(), O_CREAT | O_TRUNC | O_WRONLY, 0640);
	ASSERT_NE(fd, -1);
	ASSERT_EQ(write(fd, &file_head, sizeof(file_head)), (ssize_t)sizeof(file_head));
	ASSERT_EQ(write(fd, &record, sizeof(record)), (ssize_t)sizeof(record));
	ASSERT_EQ(write(fd, &data_head, sizeof(data_head)), (ssize_t)sizeof(data_head));
	close(fd);

	server_upstream.Start("udp://0.0.0.0:62053", [](struct smartdns::ServerRequestContext *request) {
		if (request->qtype == DNS_T_A) {
			smartdns::MockServer::AddIP(request, request->domain.c_str(), "1.2.3.4");
			return smartdns::SERVER_REQUEST_OK;
		}
		return smartdns::SERVER_REQUEST_SOA;
	});

	smartdns::Server server;
	server.Start(conf);
	smartdns::Client client;

	ASSERT_TRUE(client.Query("a.com", 60053));
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "1.2.3.4");
}

TEST_F(Cache, cname)
{
	smartdns::MockServer server_upstream;
	smartdns::Server server;

	server_upstream.Start("udp://0.0.0.0:61053", [](struct smartdns::ServerRequestContext *request) {
		std::string domain = request->domain;
		if (request->qtype != DNS_T_A) {
			return smartdns::SERVER_REQUEST_SOA;
		}

		if (domain == "a.com") {
			unsigned char addr[4] = {1, 2, 3, 4};
			dns_add_domain(request->response_packet, domain.c_str(), DNS_T_A, DNS_C_IN);
			dns_add_CNAME(request->response_packet, DNS_RRS_AN, domain.c_str(), 300, "cdn.other.example");
			/* The additional section is not an independent cache response for the CNAME target. */
			dns_add_A(request->response_packet, DNS_RRS_NR, "cdn.other.example", 300, addr);
		} else if (domain == "cdn.other.example") {
			unsigned char addr[4] = {5, 6, 7, 8};
			dns_add_A(request->response_packet, DNS_RRS_AN, domain.c_str(), 300, addr);
		} else {
			return smartdns::SERVER_REQUEST_SOA;
		}

		request->response_packet->head.rcode = DNS_RC_NOERROR;
		return smartdns::SERVER_REQUEST_OK;
	});

	server.Start(R"""(bind [::]:60053
server 127.0.0.1:61053
cache-size 100
)""");
	smartdns::Client client;
	ASSERT_TRUE(client.Query("a.com A", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 2);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "a.com");
	EXPECT_GE(client.GetAnswer()[0].GetTTL(), 3);
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "cdn.other.example.");
	EXPECT_EQ(client.GetAnswer()[1].GetName(), "cdn.other.example");
	EXPECT_GE(client.GetAnswer()[1].GetTTL(), 3);
	EXPECT_EQ(client.GetAnswer()[1].GetData(), "1.2.3.4");

	/* A CNAME response must not pre-populate the independent target cache key. */
	ASSERT_TRUE(client.Query("cdn.other.example A", 60053));
	std::cout << client.GetResult() << std::endl;
	ASSERT_EQ(client.GetAnswerNum(), 1);
	EXPECT_EQ(client.GetStatus(), "NOERROR");
	EXPECT_EQ(client.GetAnswer()[0].GetName(), "cdn.other.example");
	EXPECT_EQ(client.GetAnswer()[0].GetData(), "5.6.7.8");
}
