/*************************************************************************
 *
 * Copyright (C) 2018-2025 Ruilin Peng (Nick) <pymumu@gmail.com>.
 *
 * smartdns is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * smartdns is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "client.h"
#include "smartdns/fast_ping.h"
#include "include/utils.h"
#include "server.h"
#include "smartdns/tlog.h"
#include "gtest/gtest.h"

class Ping : public ::testing::Test
{
  protected:
	virtual void SetUp()
	{
		EXPECT_EQ(fast_ping_init(), 0);
		loglevel = tlog_getlevel();
		tlog_setlevel(TLOG_DEBUG);
	}
	virtual void TearDown()
	{
		fast_ping_exit();
		tlog_setlevel(loglevel);
	}

  private:
	tlog_level loglevel;
};

void ping_result_callback(struct ping_host_struct *ping_host, const char *host, FAST_PING_RESULT result,
						  struct sockaddr *addr, socklen_t addr_len, int seqno, int ttl, struct timeval *tv, int error,
						  void *userptr)
{
	int *count = (int *)userptr;
	if (result == PING_RESULT_RESPONSE) {
		*count = 1;
		tlog(TLOG_INFO, "ping to %s succeeded, seq=%d, ttl=%d", host, seqno, ttl);
	}
}

TEST_F(Ping, icmp)
{
	struct ping_host_struct *ping_host;
	int count = 0;
	
	if (smartdns::IsICMPAvailable() == false) {
		tlog(TLOG_INFO, "ICMP is not available, skip this test.");
		GTEST_SKIP();
		return;
	}

	ping_host = fast_ping_start(PING_TYPE_ICMP, "127.0.0.1", 1, 1, 200, ping_result_callback, &count);
	ASSERT_NE(ping_host, nullptr);
	usleep(10000);
	fast_ping_stop(ping_host);
	EXPECT_EQ(count, 1);
}

TEST_F(Ping, tcp)
{
	struct ping_host_struct *ping_host;
	int count = 0;
	ping_host = fast_ping_start(PING_TYPE_TCP, "127.0.0.1:1", 1, 1, 200, ping_result_callback, &count);
	ASSERT_NE(ping_host, nullptr);
	usleep(10000);
	fast_ping_stop(ping_host);
	EXPECT_EQ(count, 1);
}

TEST_F(Ping, tcp_syn)
{
	struct ping_host_struct *ping_host;
	int count = 0;
	
	/* Test TCP SYN ping - may not work in all environments */
	ping_host = fast_ping_start(PING_TYPE_TCP_SYN, "127.0.0.1:53", 5, 1000, 1000, ping_result_callback, &count);
	if (ping_host == nullptr) {
		tlog(TLOG_INFO, "TCP SYN ping not available (need root/CAP_NET_RAW), skip this test.");
		GTEST_SKIP();
		return;
	}
	
	usleep(10000);
	fast_ping_stop(ping_host);
	
	EXPECT_GT(count, 0);
}

TEST_F(Ping, tcp_syn_v6)
{
	struct ping_host_struct *ping_host;
	int count = 0;

	/* Test TCP SYN ping - may not work in all environments */
	ping_host = fast_ping_start(PING_TYPE_TCP_SYN, "[::1]:443", 2, 1000, 1000, ping_result_callback, &count);
	if (ping_host == nullptr) {
		tlog(TLOG_INFO, "TCP SYN ping not available (need root/CAP_NET_RAW), skip this test.");
		GTEST_SKIP();
		return;
	}
	
	usleep(1000000);
	fast_ping_stop(ping_host);
	
	EXPECT_GT(count, 0);
}

TEST_F(Ping, tcp_syn_concurrent)
{
	struct ping_host_struct *ping_host1;
	struct ping_host_struct *ping_host2;
	int count1 = 0, count2 = 0;
	
	/* Test concurrent TCP SYN pings to different servers */
	ping_host1 = fast_ping_start(PING_TYPE_TCP_SYN, "127.0.0.1:22", 1, 1, 500, ping_result_callback, &count1);
	if (ping_host1 == nullptr) {
		tlog(TLOG_INFO, "TCP SYN ping not available, skip this test.");
		GTEST_SKIP();
		return;
	}
	
	tlog(TLOG_INFO, "First ping started, now starting second...");
	
	/* Use Alibaba DNS server (accessible in China) */
	ping_host2 = fast_ping_start(PING_TYPE_TCP_SYN, "127.0.0.2:53", 1, 1, 500, ping_result_callback, &count2);
	ASSERT_NE(ping_host2, nullptr);
	
	tlog(TLOG_INFO, "Both pings started, waiting 200ms...");
	usleep(200000); /* Wait 200ms for responses */
	
	tlog(TLOG_INFO, "Wait complete, stopping pings...");
	fast_ping_stop(ping_host1);
	fast_ping_stop(ping_host2);
	usleep(50000); /* Brief wait for cleanup */
	
	tlog(TLOG_INFO, "TCP SYN concurrent ping test completed, count1=%d, count2=%d", count1, count2);
	
	/* At least one should succeed (localhost SSH should be reachable) */
	EXPECT_GE(count1 + count2, 1);
}

void fake_ping_result_callback(struct ping_host_struct *ping_host, const char *host, FAST_PING_RESULT result,
							   struct sockaddr *addr, socklen_t addr_len, int seqno, int ttl, struct timeval *tv,
							   int error, void *userptr)
{
	if (result == PING_RESULT_RESPONSE) {
		int *count = (int *)userptr;
		double rtt = tv->tv_sec * 1000.0 + tv->tv_usec / 1000.0;
		tlog(TLOG_INFO, "from %15s: seq=%d ttl=%d time=%.3f\n", host, seqno, ttl, rtt);
		*count = (int)rtt;
	}
}

TEST_F(Ping, fake_icmp)
{
	struct ping_host_struct *ping_host;
	int count = 0;
	fast_ping_fake_ip_add(PING_TYPE_ICMP, "1.2.3.4", 60, 5);
	ping_host = fast_ping_start(PING_TYPE_ICMP, "1.2.3.4", 1, 1000, 200, fake_ping_result_callback, &count);
	ASSERT_NE(ping_host, nullptr);
	usleep(100000);
	fast_ping_stop(ping_host);
	EXPECT_GE(count, 5);
}
